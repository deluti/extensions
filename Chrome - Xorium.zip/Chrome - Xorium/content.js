// Content script для замены изображений
let settings = null;
let isEnabled = false;
let replacedCount = 0;

// Загружаем настройки при загрузке страницы
loadSettings();

// Загружаем настройки из storage
function loadSettings() {
  chrome.storage.local.get(['enabled', 'mode', 'selectedImage', 'images'], (result) => {
    settings = result;
    isEnabled = result.enabled || false;
    
    if (isEnabled) {
      enableReplacement();
    }
  });
}

// Включение замены изображений
function enableReplacement() {
  if (!isEnabled || !settings || !settings.images || settings.images.length === 0) {
    return;
  }
  
  console.log('Image Replacer: включено');
  replacedCount = 0;
  
  // Заменяем существующие изображения
  replaceAllImages();
  
  // Начинаем отслеживать новые изображения
  startObserving();
}

// Отключение замены изображений
function disableReplacement() {
  console.log('Image Replacer: выключено');
  isEnabled = false;
  
  // Восстанавливаем оригинальные изображения
  restoreAllImages();
  
  // Останавливаем отслеживание
  if (observer) {
    observer.disconnect();
    observer = null;
  }
}

// Замена всех изображений
function replaceAllImages() {
  const allImages = document.querySelectorAll('img');
  
  allImages.forEach(img => {
    if (shouldReplaceImage(img)) {
      replaceImage(img);
    }
  });
}

// Проверка, нужно ли заменять изображение
function shouldReplaceImage(img) {
  // Пропускаем уже замененные
  if (img.hasAttribute('data-replaced')) {
    return false;
  }
  
  // Пропускаем очень маленькие
  if (img.width < 30 && img.height < 30) {
    return false;
  }
  
  // Пропускаем скрытые
  const style = window.getComputedStyle(img);
  if (style.display === 'none' || style.visibility === 'hidden') {
    return false;
  }
  
  return true;
}

// Замена одного изображения
function replaceImage(img) {
  try {
    if (!settings.images || settings.images.length === 0) return;
    
    // Выбираем картинку
    let imageIndex = 0;
    if (settings.mode === 'specific' && settings.selectedImage !== null) {
      imageIndex = parseInt(settings.selectedImage);
      if (isNaN(imageIndex) || imageIndex >= settings.images.length) {
        imageIndex = 0;
      }
    } else if (settings.mode === 'random') {
      imageIndex = Math.floor(Math.random() * settings.images.length);
    }
    
    const imageData = settings.images[imageIndex];
    if (!imageData || !imageData.dataUrl) return;
    
    // Сохраняем оригинальный src
    img.setAttribute('data-original-src', img.src);
    img.setAttribute('data-replaced', 'true');
    
    // Сохраняем размеры
    const originalWidth = img.width;
    const originalHeight = img.height;
    
    // Заменяем
    img.src = imageData.dataUrl;
    
    // Восстанавливаем размеры
    if (originalWidth) img.width = originalWidth;
    if (originalHeight) img.height = originalHeight;
    
    // Счетчик
    replacedCount++;
    
    // Обработка ошибок
    img.onerror = function() {
      restoreImage(img);
    };
    
  } catch (error) {
    console.error('Ошибка замены:', error);
  }
}

// Восстановление одного изображения
function restoreImage(img) {
  const originalSrc = img.getAttribute('data-original-src');
  if (originalSrc) {
    img.src = originalSrc;
  }
  
  img.removeAttribute('data-replaced');
  img.removeAttribute('data-original-src');
  img.onerror = null;
  
  replacedCount = Math.max(0, replacedCount - 1);
}

// Восстановление всех изображений
function restoreAllImages() {
  const replacedImages = document.querySelectorAll('img[data-replaced]');
  
  replacedImages.forEach(img => {
    restoreImage(img);
  });
  
  replacedCount = 0;
}

// Наблюдатель за DOM
let observer = null;
function startObserving() {
  if (observer) observer.disconnect();
  
  observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.addedNodes.length) {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === 1 && node.tagName === 'IMG') {
            if (shouldReplaceImage(node)) {
              setTimeout(() => replaceImage(node), 100);
            }
          } else if (node.querySelectorAll) {
            const images = node.querySelectorAll('img');
            images.forEach(img => {
              if (shouldReplaceImage(img)) {
                setTimeout(() => replaceImage(img), 100);
              }
            });
          }
        });
      }
    });
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

// Обработчик сообщений от popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case 'ping':
      sendResponse({ replacedCount: replacedCount });
      break;
      
    case 'applySettings':
      settings = message.settings;
      isEnabled = message.settings.enabled;
      
      if (isEnabled) {
        // Удаляем старые замены
        restoreAllImages();
        // Включаем новую замену
        setTimeout(() => enableReplacement(), 100);
      } else {
        disableReplacement();
      }
      
      sendResponse({ success: true });
      break;
      
    case 'disableExtension':
      disableReplacement();
      sendResponse({ success: true });
      break;
  }
  
  return true;
});

// Также отслеживаем SPA навигацию
let lastUrl = location.href;
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    // При смене URL перезапускаем
    setTimeout(() => {
      if (isEnabled) {
        restoreAllImages();
        setTimeout(() => enableReplacement(), 500);
      }
    }, 100);
  }
}).observe(document, { subtree: true, childList: true });