// В самом начале файла добавьте проверку контекста
(function() {
  // Проверяем, запущены ли мы в отдельном окне
  const isStandaloneWindow = window.location.protocol === 'chrome-extension:' || 
                           window.location.protocol === 'moz-extension:';
  
  if (!isStandaloneWindow) {
    // Если это не standalone окно, значит это обычный popup
    // Используем стандартный код
    initializePopup();
  } else {
    // Если это standalone окно, используем расширенный функционал
    initializeStandaloneWindow();
  }

  async function initializePopup() {
    // Оригинальный код для popup (ваш текущий код)
    // ...
  }

  async function initializeStandaloneWindow() {
    // Улучшенный код для standalone окна
    
    // Elements
    const modeOptions = document.querySelectorAll('.mode-option');
    const specificSection = document.getElementById('specific-section');
    const randomSection = document.getElementById('random-section');
    const imageSelect = document.getElementById('imageSelect');
    const imagePreview = document.getElementById('imagePreview');
    const refreshImagesBtn = document.getElementById('refreshImages');
    const removeAllBtn = document.getElementById('removeAll');
    const showInstructionsBtn = document.getElementById('showInstructions');
    const extensionToggle = document.getElementById('extensionToggle');
    const statusMessage = document.getElementById('statusMessage');
    const imageCount = document.getElementById('imageCount');
    const replacedCount = document.getElementById('replacedCount');
    const instructionsModal = document.getElementById('instructionsModal');
    const closeModalBtn = document.querySelector('.close-modal');

    let currentMode = 'specific';
    let images = [];
    let isEnabled = false;

    // Инициализация
    await init();

    // Включение/выключение расширения
    extensionToggle.addEventListener('change', async () => {
      isEnabled = extensionToggle.checked;
      await saveSettings();
      
      if (isEnabled) {
        updateStatus('Включено', 'success');
        await applySettings();
      } else {
        updateStatus('Выключено', 'info');
        await disableExtension();
      }
    });

    // Выбор режима
    modeOptions.forEach(option => {
      option.addEventListener('click', () => {
        modeOptions.forEach(o => o.classList.remove('active'));
        option.classList.add('active');
        currentMode = option.dataset.mode;
        
        if (currentMode === 'specific') {
          specificSection.style.display = 'block';
          randomSection.style.display = 'none';
        } else {
          specificSection.style.display = 'none';
          randomSection.style.display = 'block';
        }
        
        updateStatus('Режим изменен', 'success');
        saveAndApply();
      });
    });

    // Выбор картинки
    imageSelect.addEventListener('change', () => {
      updateImagePreview();
      saveAndApply();
    });

    // Загрузка новых картинок - используем input без страха закрытия
    refreshImagesBtn.addEventListener('click', () => {
      const input = document.createElement('input');
      input.type = 'file';
      input.multiple = true;
      input.accept = 'image/jpeg,image/png,image/gif,image/webp';
      input.style.display = 'none';
      
      input.onchange = async function(event) {
        const files = Array.from(event.target.files);
        if (files.length === 0) return;
        
        await processFiles(files);
        document.body.removeChild(input);
      };
      
      document.body.appendChild(input);
      input.click();
    });

    // Удаление всех картинок
    removeAllBtn.addEventListener('click', async () => {
      if (confirm('Удалить все картинки из коллекции?')) {
        images = [];
        updateImageSelect();
        updateStats();
        await saveSettings();
        updateStatus('Все картинки удалены', 'success');
        
        if (isEnabled) {
          await applySettings();
        }
      }
    });

    // Показать инструкцию
    showInstructionsBtn.addEventListener('click', () => {
      instructionsModal.style.display = 'flex';
    });

    // Закрыть модальное окно
    closeModalBtn.addEventListener('click', () => {
      instructionsModal.style.display = 'none';
    });

    // Закрыть модальное окно при клике на overlay
    instructionsModal.addEventListener('click', (e) => {
      if (e.target === instructionsModal) {
        instructionsModal.style.display = 'none';
      }
    });

    async function processFiles(files) {
      updateStatus(`Загрузка ${files.length} картинок...`, 'pending');
      
      let loadedCount = 0;
      const errors = [];

      for (const file of files) {
        try {
          if (!file.type.match('image.*')) {
            errors.push(`${file.name}: не изображение`);
            continue;
          }

          if (file.size > 5 * 1024 * 1024) {
            errors.push(`${file.name}: больше 5MB`);
            continue;
          }

          const dataUrl = await readFileAsDataURL(file);
          
          images.push({
            name: file.name,
            dataUrl: dataUrl,
            type: file.type,
            size: file.size,
            id: Date.now() + Math.random()
          });
          
          loadedCount++;
        } catch (error) {
          errors.push(`${file.name}: ошибка загрузки`);
        }
      }

      updateImageSelect();
      updateStats();
      await saveSettings();
      
      let message = `Загружено ${loadedCount} из ${files.length} картинок`;
      if (errors.length > 0) {
        message += `. Ошибки: ${errors.join(', ')}`;
        updateStatus(message, 'warning');
      } else {
        updateStatus(message, 'success');
      }
      
      if (isEnabled && loadedCount > 0) {
        await applySettings();
      }
    }

    // Функция чтения файла как Data URL
    function readFileAsDataURL(file) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    }

    async function init() {
      // Загружаем настройки
      const settings = await browser.storage.local.get([
        'enabled', 
        'mode', 
        'selectedImage', 
        'images'
      ]);
      
      if (settings.enabled !== undefined) {
        isEnabled = settings.enabled;
        extensionToggle.checked = isEnabled;
      }

      if (settings.mode) {
        currentMode = settings.mode;
        const activeOption = document.querySelector(`.mode-option[data-mode="${currentMode}"]`);
        if (activeOption) {
          modeOptions.forEach(o => o.classList.remove('active'));
          activeOption.classList.add('active');
          
          if (currentMode === 'random') {
            specificSection.style.display = 'none';
            randomSection.style.display = 'block';
          }
        }
      }

      if (settings.images && Array.isArray(settings.images)) {
        images = settings.images;
      }
      
      updateImageSelect();
      updateStats();
      
      if (settings.selectedImage !== undefined && imageSelect) {
        imageSelect.value = settings.selectedImage;
        updateImagePreview();
      }
      
      // Проверяем статус на активной вкладке
      checkTabStatus();
      setInterval(checkTabStatus, 3000);
    }

    function updateImageSelect() {
      if (!imageSelect) return;
      
      const currentValue = imageSelect.value;
      imageSelect.innerHTML = '<option value="">Выберите картинку</option>';
      
      images.forEach((image, index) => {
        const option = document.createElement('option');
        option.value = index;
        option.textContent = image.name.length > 30 
          ? image.name.substring(0, 30) + '...' 
          : image.name;
        option.title = image.name;
        imageSelect.appendChild(option);
      });

      if (currentValue !== '' && images[currentValue]) {
        imageSelect.value = currentValue;
      }
    }

    function updateImagePreview() {
      if (!imagePreview) return;
      
      const selectedIndex = imageSelect.value;
      
      if (selectedIndex === '' || selectedIndex === undefined || !images[selectedIndex]) {
        imagePreview.innerHTML = `
          <div class="preview-placeholder">
            <i class="fas fa-image"></i>
            <span>Выберите картинку для предпросмотра</span>
          </div>
        `;
        return;
      }

      const image = images[selectedIndex];
      const img = document.createElement('img');
      img.src = image.dataUrl;
      img.alt = 'Preview';
      img.style.cssText = 'max-width: 100%; max-height: 100%; object-fit: contain; opacity: 0; transition: opacity 0.3s;';
      
      img.onload = function() {
        this.style.opacity = '1';
      };
      
      img.onerror = function() {
        imagePreview.innerHTML = `
          <div class="preview-placeholder">
            <i class="fas fa-exclamation-circle"></i>
            <span>Ошибка загрузки</span>
          </div>
        `;
      };
      
      imagePreview.innerHTML = '';
      imagePreview.appendChild(img);
    }

    function updateStats() {
      if (imageCount) {
        imageCount.textContent = images.length;
      }
      
      // В standalone окне замененные картинки показываем по-другому
      if (replacedCount) {
        replacedCount.textContent = 'N/A';
      }
    }

    async function checkTabStatus() {
      try {
        // Получаем активную вкладку
        const tabs = await browser.tabs.query({ active: true, currentWindow: true });
        if (tabs[0]) {
          // Пробуем отправить сообщение
          browser.tabs.sendMessage(tabs[0].id, { action: 'ping' }, (response) => {
            if (browser.runtime.lastError) {
              // Content script не загружен
              if (replacedCount) replacedCount.textContent = '0';
            } else if (response && replacedCount) {
              replacedCount.textContent = response.replacedCount || '0';
            }
          });
        } else {
          if (replacedCount) replacedCount.textContent = 'N/A';
        }
      } catch (error) {
        if (replacedCount) replacedCount.textContent = 'Err';
      }
    }

    async function saveSettings() {
      const settings = {
        enabled: isEnabled,
        mode: currentMode,
        selectedImage: currentMode === 'specific' ? imageSelect.value : null,
        images: images
      };
      
      await browser.storage.local.set(settings);
      return settings;
    }

    async function saveAndApply() {
      const settings = await saveSettings();
      if (isEnabled) {
        await applySettings();
      }
    }

    async function applySettings() {
      if (images.length === 0) {
        updateStatus('Нет картинок для замены', 'warning');
        return;
      }

      updateStatus('Применение настроек...', 'pending');
      
      try {
        const tabs = await browser.tabs.query({ active: true, currentWindow: true });
        if (tabs[0]) {
          const settings = await saveSettings();
          
          browser.tabs.sendMessage(tabs[0].id, {
            action: 'applySettings',
            settings: settings
          }, (response) => {
            if (browser.runtime.lastError) {
              updateStatus('Обновите страницу для применения', 'warning');
            } else {
              updateStatus('Настройки применены', 'success');
            }
          });
        } else {
          updateStatus('Откройте страницу для применения', 'info');
        }
      } catch (error) {
        updateStatus('Обновите страницу', 'warning');
      }
    }

    async function disableExtension() {
      try {
        const tabs = await browser.tabs.query({ active: true, currentWindow: true });
        if (tabs[0]) {
          browser.tabs.sendMessage(tabs[0].id, {
            action: 'disableExtension'
          }, (response) => {
            // Игнорируем ошибки
          });
        }
      } catch (error) {
        // Игнорируем ошибки
      }
    }

    function updateStatus(message, type = 'info') {
      if (!statusMessage) return;
      
      const icon = statusMessage.querySelector('i');
      const text = statusMessage.querySelector('span');
      
      if (!icon || !text) return;
      
      statusMessage.className = `status ${type}`;
      text.textContent = message;
      
      switch(type) {
        case 'success':
          icon.className = 'fas fa-check-circle';
          break;
        case 'error':
          icon.className = 'fas fa-exclamation-circle';
          break;
        case 'warning':
          icon.className = 'fas fa-exclamation-triangle';
          break;
        case 'pending':
          icon.className = 'fas fa-spinner fa-spin';
          break;
        default:
          icon.className = 'fas fa-info-circle';
      }
    }
  }
})();