// Отслеживаем открытые окна
let settingsWindow = null;

browser.browserAction.onClicked.addListener(async (tab) => {
  // Если окно уже открыто, фокусируем его
  if (settingsWindow) {
    try {
      await browser.windows.update(settingsWindow.id, { focused: true });
      return;
    } catch (error) {
      // Окно было закрыто
      settingsWindow = null;
    }
  }

  // Создаем новое окно
  const window = await browser.windows.create({
    url: browser.runtime.getURL("popup/popup.html"),
    type: "popup",
    width: 420,
    height: 650,
    left: Math.round((screen.width - 420) / 2),
    top: Math.round((screen.height - 650) / 2)
  });

  settingsWindow = window;
  
  // Отслеживаем закрытие окна
  browser.windows.onRemoved.addListener((windowId) => {
    if (windowId === settingsWindow.id) {
      settingsWindow = null;
    }
  });
});