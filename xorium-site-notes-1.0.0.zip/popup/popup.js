// popup.js
console.log("🎮 Xorium Tasks загружен");

let current_domain = null;
let taskCounter = 1;

// Инициализация
document.addEventListener('DOMContentLoaded', async () => {
    console.log("🔧 Инициализация расширения...");
    
    // Получаем текущий домен СНАЧАЛА
    await getCurrentDomain();
    
    // Назначаем обработчик кнопки Add
    document.getElementById('create_task').addEventListener('click', createNewTask);
    
    // Загружаем задачи для текущего домена
    await loadTasksForCurrentDomain();
    
    // Назначаем обработчики для всех кнопок Save (динамически)
    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('save_task')) {
            const taskId = event.target.closest('.task').id;
            saveTask(taskId);
        }
        if (event.target.classList.contains('delete_task')) {
            const taskId = event.target.closest('.task').id;
            deleteTask(taskId);
        }
    });
});

// Получение текущего домена
async function getCurrentDomain() {
    try {
        const tabs = await browser.tabs.query({ active: true, currentWindow: true });
        if (tabs[0]?.url) {
            current_domain = extractDomain(tabs[0].url);
            document.getElementById('domen_status').textContent = `🌐 ${current_domain}`;
            console.log("📍 Текущий домен:", current_domain);
            return current_domain;
        }
    } catch (error) {
        console.error("❌ Ошибка получения домена:", error);
        document.getElementById('domen_status').textContent = "❌ Ошибка загрузки";
    }
    return null;
}

// Извлечение домена
function extractDomain(url) {
    try {
        const urlObj = new URL(url);
        let hostname = urlObj.hostname.replace(/^www\./, '');
        return hostname.split(':')[0];
    } catch (error) {
        const match = url.match(/^(?:https?:\/\/)?(?:www\.)?([^\/:]+)/i);
        return match ? match[1] : "unknown";
    }
}

// Создание новой задачи
function createNewTask() {
    const taskId = `task_${Date.now()}`;
    const tasksContainer = document.getElementById('tasks-container') || document.querySelector('.main');
    
    const taskHTML = `
        <div class="task" id="${taskId}" data-task-id="${taskId}">
            <input type="text" 
                   class="text_a task-name" 
                   placeholder="Task Name" 
                   data-task-field="name">
            <textarea 
                class="text_a task-description" 
                placeholder="Task Description"
                rows="3"
                data-task-field="description"></textarea>
            
            <div class="task-buttons">
                <button class="save_task" data-task-id="${taskId}">
                    💾 Save
                </button>
                <button class="delete_task" data-task-id="${taskId}">
                    🗑️ Delete
                </button>
            </div>
        </div>
    `;
    
    if (tasksContainer.id === 'tasks-container') {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = taskHTML; // всё ещё innerHTML, но в временном элементе
        while (tempDiv.firstChild) {
            tasksContainer.appendChild(tempDiv.firstChild);
        }
    } else {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = taskHTML;
        tasksContainer.appendChild(tempDiv.children[0]);
    }
    
    // Анимация появления
    const newTask = document.getElementById(taskId);
    newTask.style.animation = 'fadeIn 0.4s ease-out';
    
    console.log("➕ Создана новая задача:", taskId);
}

// Сохранение задачи
async function saveTask(taskId) {
    console.log("💾 Сохранение задачи:", taskId);
    
    // Проверяем, определен ли домен
    if (!current_domain) {
        current_domain = await getCurrentDomain();
        if (!current_domain) {
            alert("⚠️ Не удалось определить домен! Обновите страницу.");
            return;
        }
    }
    
    const taskElement = document.getElementById(taskId);
    if (!taskElement) {
        console.error("❌ Элемент задачи не найден:", taskId);
        return;
    }
    
    const taskName = taskElement.querySelector('.task-name').value.trim();
    const taskDescription = taskElement.querySelector('.task-description').value.trim();
    
    if (!taskName && !taskDescription) {
        alert("⚠️ Заполните хотя бы одно поле!");
        return;
    }
    
    const taskData = {
        id: taskId,
        name: taskName || `Task ${taskCounter++}`,
        description: taskDescription || '',
        domain: current_domain,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    };
    
    console.log("📝 Данные для сохранения:", taskData);
    
    try {
        // Получаем существующие задачи
        const data = await browser.storage.local.get(['tasks']);
        console.log("📦 Текущие данные в storage:", data);
        
        const allTasks = data.tasks || {};
        
        // Инициализируем массив для домена
        if (!allTasks[current_domain]) {
            allTasks[current_domain] = [];
        }
        
        // Проверяем, существует ли уже задача
        const existingIndex = allTasks[current_domain].findIndex(t => t.id === taskId);
        
        if (existingIndex >= 0) {
            // Обновляем существующую
            allTasks[current_domain][existingIndex] = taskData;
            console.log("🔄 Обновлена существующая задача");
        } else {
            // Добавляем новую
            allTasks[current_domain].push(taskData);
            console.log("✨ Добавлена новая задача");
        }
        
        // Сохраняем
        await browser.storage.local.set({ tasks: allTasks });
        console.log("✅ Данные сохранены в storage");
        
        // Визуальный фидбэк
        const saveBtn = taskElement.querySelector('.save_task');
        const originalText = saveBtn.textContent;
        const originalBg = saveBtn.style.background;
        
        saveBtn.textContent = '✅ Saved!';
        saveBtn.style.background = 'linear-gradient(145deg, #2a8a2a, #1a5a1a)';
        saveBtn.style.cursor = 'default';
        
        setTimeout(() => {
            saveBtn.textContent = originalText;
            saveBtn.style.background = originalBg;
            saveBtn.style.cursor = 'pointer';
        }, 1500);
        
        // Проверяем, что сохранилось
        const checkData = await browser.storage.local.get(['tasks']);
        console.log("🔍 Проверка сохраненных данных:", checkData.tasks?.[current_domain]);
        
    } catch (error) {
        console.error("❌ Ошибка сохранения:", error);
        alert("❌ Ошибка сохранения задачи: " + error.message);
    }
}

// Удаление задачи
async function deleteTask(taskId) {
    if (!confirm("🗑️ Удалить эту задачу?")) return;
    
    const taskElement = document.getElementById(taskId);
    if (!taskElement) return;
    
    // Получаем текущий домен если ещё не получен
    if (!current_domain) {
        current_domain = await getCurrentDomain();
    }
    
    // Анимация удаления
    taskElement.style.animation = 'fadeOut 0.3s ease-out';
    setTimeout(async () => {
        taskElement.remove();
        
        // Удаляем из storage
        if (current_domain) {
            try {
                const data = await browser.storage.local.get(['tasks']);
                console.log("📦 Данные перед удалением:", data);
                
                if (data.tasks?.[current_domain]) {
                    const beforeLength = data.tasks[current_domain].length;
                    data.tasks[current_domain] = data.tasks[current_domain].filter(t => t.id !== taskId);
                    const afterLength = data.tasks[current_domain].length;
                    
                    console.log(`🗑️ Удалено задач: ${beforeLength - afterLength}`);
                    
                    // Если задач не осталось - удаляем домен
                    if (data.tasks[current_domain].length === 0) {
                        delete data.tasks[current_domain];
                        console.log("🗑️ Домен удален (не осталось задач)");
                    }
                    
                    await browser.storage.local.set({ tasks: data.tasks });
                    console.log("✅ Данные обновлены после удаления");
                    
                    // Проверяем результат
                    const checkData = await browser.storage.local.get(['tasks']);
                    console.log("🔍 Данные после удаления:", checkData);
                }
            } catch (error) {
                console.error("❌ Ошибка удаления из storage:", error);
                alert("Ошибка удаления задачи");
            }
        }
    }, 300);
}

// Загрузка задач для текущего домена
async function loadTasksForCurrentDomain() {
    // Ждем получения домена
    if (!current_domain) {
        current_domain = await getCurrentDomain();
    }
    
    if (!current_domain) {
        console.error("❌ Не удалось получить домен для загрузки задач");
        return;
    }
    
    try {
        const data = await browser.storage.local.get(['tasks']);
        const domainTasks = data.tasks?.[current_domain] || [];
        
        const tasksContainer = document.getElementById('tasks-container');
        if (!tasksContainer) {
            // Создаем контейнер если его нет
            const main = document.querySelector('.main');
            const container = document.createElement('div');
            container.id = 'tasks-container';
            main.appendChild(container);
        }
        
        const container = document.getElementById('tasks-container');
        container.innerHTML = '';
        
        console.log(`📂 Загружено ${domainTasks.length} задач для ${current_domain}`);
        
        // Создаём элементы для каждой задачи
        domainTasks.forEach(task => {
            const taskHTML = `
                <div class="task" id="${task.id}" data-task-id="${task.id}">
                    <input type="text" 
                           class="text_a task-name" 
                           placeholder="Task Name" 
                           value="${(task.name || '').replace(/"/g, '&quot;')}"
                           data-task-field="name">
                    <textarea 
                        class="text_a task-description" 
                        placeholder="Task Description"
                        rows="3"
                        data-task-field="description">${task.description || ''}</textarea>
                    
                    <div class="task-buttons">
                        <button class="save_task" data-task-id="${task.id}">
                            💾 Save
                        </button>
                        <button class="delete_task" data-task-id="${task.id}">
                            🗑️ Delete
                        </button>
                    </div>
                </div>
            `;
            
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = taskHTML;
            while (tempDiv.firstChild) {
                container.appendChild(tempDiv.firstChild);
            }
        });
        
    } catch (error) {
        console.error("❌ Ошибка загрузки задач:", error);
    }
}

// Анимация fadeOut (добавить в CSS)
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeOut {
        from { opacity: 1; transform: translateY(0); }
        to { opacity: 0; transform: translateY(-10px); }
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    #tasks-container {
        width: 100%;
        display: flex;
        flex-direction: column;
        gap: 15px;
        margin-top: 10px;
    }
`;
document.head.appendChild(style);

// Экспортируем функции для глобального использования
window.saveTask = saveTask;
window.deleteTask = deleteTask;
window.createNewTask = createNewTask;