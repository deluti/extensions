# Xorium Site Notes

Save personal notes for any website! Your notes automatically appear when you return to the site.

## Features:
- Save notes for specific websites
- Auto-detects current website
- Dark theme with beautiful UI
- All data stored locally (private)
- One-click task management

## Privacy:
- No data collection
- No tracking
- No external servers
- Everything stays in your browser

## Support:
For issues or suggestions, contact: delution27@gmail.com