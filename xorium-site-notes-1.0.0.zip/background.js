// Фоновый скрипт
console.log('Background service worker is run!');
// Обработчик установки
chrome.runtime.onInstalled.addListener(() => {
  console.log('The extension was installed successfully.!');
});